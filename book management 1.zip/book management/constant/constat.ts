export const dburl = "mongodb+srv://gautam:gautam123@cluster0.cqqenfr.mongodb.net"
export const dbname = "book_management"
export const PORT = 8586;
export const JWT_SECRET = "hellogautam"
